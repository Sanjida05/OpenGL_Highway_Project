#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include<stdio.h>
#include<cmath>



int x_incement=0;
int x1_incement=0; // left side move

void init()
{
    glClearColor(1.0,1.0,1.0, 0.0);
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0.0, 1000.0, 0.0, 700.0);
    glMatrixMode(GL_MODELVIEW);
}
// used reshape so that my object don't distord

void reshape( int width,int height)
{
    glClearColor(0, 0 ,0, 0.0);
    glViewport(0,0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluOrtho2D(0.0,width,0.0,height);


    if (width < 1000 || height < 700)
    {
        glutReshapeWindow(1000, 700);
    }

    glMatrixMode(GL_MODELVIEW);

}

void keyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 27:
        exit(0); //window close
        break;

    case 'F':
    case 'f':
        glutFullScreen();
        break;



    case 'm':
    case 'M':
        glutPositionWindow(200, 200);
        glutReshapeWindow(500,500);
        break;


    }
}

void makeCircle(int r, double x_center, double y_center, bool isFill)
{
    int deg = 0;
    double theta, x = x_center, y = y_center;

    if(isFill)
    {
        glBegin(GL_TRIANGLE_FAN);
    }
    else
    {
        glBegin(GL_POINTS);
    }
    glPointSize(3);

    glVertex2d(x, y);
    while(deg <= 360)
    {
        theta = (deg* M_PI)/180;
        x = x_center + r * cos(theta);
        y = y_center + r * sin(theta);



        glVertex2d(x, y);
        deg+=1;
    }
    glEnd();
}

void tree(int x, int y)
{
    glColor3ub(254, 234, 34);
    glRecti(x-5, y-20, x+5, y-10);

    glColor3ub(34, 230, 20);
    makeCircle(10, x-10, y, 1);
    makeCircle(10, x-5, y, 1);
    makeCircle(10, x, y, 1);
    makeCircle(10, x+5, y, 1);
    makeCircle(10, x+10, y, 1);


    makeCircle(10, x-5, y+10, 1);
    makeCircle(10, x, y+10, 1);
    makeCircle(10, x+5, y+10, 1);


    makeCircle(10, x, y+15, 1);



    // makeCircle(10,);

}



void cloud()
{

    glColor3ub(255,255,255);

//1st cloud


    makeCircle(30,420,650,1);
    makeCircle(30,440,650,1);
    makeCircle(30,420,630,1);
    //makeCircle(30,420,630,1);
    makeCircle(30,460,640,1);
    makeCircle(30,390,640,1);



//2nd cloud
    makeCircle(30,750,650,1);
    makeCircle(30,770,650,1);
    makeCircle(30,750,630,1);
    makeCircle(30,770,630,1);
    makeCircle(30,790,640,1);
    makeCircle(30,720,640,1);


}

void sun(){

    //sun

    glColor3ub(253, 184, 19 );
    makeCircle(30,580,640,1);



}


void sky()
{
    glBegin(GL_QUADS);
    glColor3ub(135, 206, 235);
    glVertex2i(0,520);
    glVertex2i(0,700);
    glVertex2i(1000,700);
    glVertex2i(1000,520);
    glEnd();

    //1st house

    glBegin(GL_POLYGON);
    glColor3ub(185, 6, 35);
    glVertex2i(50,520);
    glVertex2i(50,610);
    glVertex2i(110,610);
    glVertex2i(120,600);
    glVertex2i(120,520);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(5, 20, 5);
    glVertex2i(70,530);
    glVertex2i(70,560);
    glVertex2i(100,560);
    glVertex2i(100,530);

    glColor3ub(0, 0, 5);
    glVertex2i(70,570);
    glVertex2i(70,600);
    glVertex2i(100,600);
    glVertex2i(100,570);

    glEnd();

//2nd house
    glBegin(GL_POLYGON);
    glColor3ub(0,0,153);
    glVertex2i(180,520);
    glVertex2i(180,590);
    glVertex2i(240,590);
    glVertex2i(250,580);
    glVertex2i(250,520);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(5, 20, 5);
    glVertex2i(200,550);
    glVertex2i(200,570);
    glVertex2i(240,570);
    glVertex2i(240,550);
    glEnd();

//3rd house
    glBegin(GL_POLYGON);
    glColor3ub(255,102,255);
    glVertex2i(280,520);
    glVertex2i(280,630);
    glVertex2i(340,630);
    glVertex2i(350,620);
    glVertex2i(350,520);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(5, 20, 5);
    glVertex2i(290,530);
    glVertex2i(290,550);
    glVertex2i(310,550);
    glVertex2i(310,530);

    glVertex2i(290,560);
    glVertex2i(290,580);
    glVertex2i(310,580);
    glVertex2i(310,560);

    glVertex2i(290,600);
    glVertex2i(290,620);
    glVertex2i(310,620);
    glVertex2i(310,600);

    glVertex2i(320,530);
    glVertex2i(320,550);
    glVertex2i(340,550);
    glVertex2i(340,530);

    glVertex2i(320,560);
    glVertex2i(320,580);
    glVertex2i(340,580);
    glVertex2i(340,560);

    glVertex2i(320,600);
    glVertex2i(320,620);
    glVertex2i(340,620);
    glVertex2i(340,600);


    glEnd();


//4th house

    glBegin(GL_POLYGON);
    glColor3ub(255,102,102);
    glVertex2i(420,520);
    glVertex2i(420,590);
    glVertex2i(510,590);
    glVertex2i(520,580);
    glVertex2i(520,520);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(5, 20, 5);
    glVertex2i(430,530);
    glVertex2i(430,550);
    glVertex2i(460,550);
    glVertex2i(460,530);

    glVertex2i(430,560);
    glVertex2i(430,580);
    glVertex2i(460,580);
    glVertex2i(460,560);

    glVertex2i(480,530);
    glVertex2i(480,550);
    glVertex2i(510,550);
    glVertex2i(510,530);

    glVertex2i(480,560);
    glVertex2i(480,580);
    glVertex2i(510,580);
    glVertex2i(510,560);

    glEnd();

    //5th house

    glBegin(GL_POLYGON);
    glColor3ub(153,0,153);
    glVertex2i(610,520);
    glVertex2i(610,590);
    glVertex2i(690,590);
    glVertex2i(700,580);
    glVertex2i(700,520);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(5, 20, 5);
    glVertex2i(620,530);
    glVertex2i(620,550);
    glVertex2i(650,550);
    glVertex2i(650,530);

    glVertex2i(620,560);
    glVertex2i(620,580);
    glVertex2i(650,580);
    glVertex2i(650,560);

    glVertex2i(660,530);
    glVertex2i(660,550);
    glVertex2i(690,550);
    glVertex2i(690,530);

    glVertex2i(660,560);
    glVertex2i(660,580);
    glVertex2i(690,580);
    glVertex2i(690,560);

    glEnd();

    //6th house

    glBegin(GL_POLYGON);
    glColor3ub(102,204,0);
    glVertex2i(820,520);
    glVertex2i(820,630);
    glVertex2i(900,630);
    glVertex2i(910,620);
    glVertex2i(910,520);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(5, 20, 5);
    glVertex2i(830,530);
    glVertex2i(830,560);
    glVertex2i(860,560);
    glVertex2i(860,530);

    glVertex2i(830,580);
    glVertex2i(830,610);
    glVertex2i(860,610);
    glVertex2i(860,580);

    glVertex2i(870,530);
    glVertex2i(870,560);
    glVertex2i(900,560);
    glVertex2i(900,530);

    glVertex2i(870,580);
    glVertex2i(870,610);
    glVertex2i(900,610);
    glVertex2i(900,580);

    glEnd();

}

void block1()
{

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2i(0,500);
    glVertex2i(0,520);
    glVertex2i(1000,520);
    glVertex2i(1000,500);
    glEnd();

    //white color

    glBegin(GL_QUADS);
    glColor3ub(255,255,255);
    glVertex2i(100,500);
    glVertex2i(100,520);
    glVertex2i(200,520);
    glVertex2i(200,500);

    glVertex2i(300,500);
    glVertex2i(300,520);
    glVertex2i(400,520);
    glVertex2i(400,500);

    glVertex2i(500,500);
    glVertex2i(500,520);
    glVertex2i(600,520);
    glVertex2i(600,500);

    glVertex2i(700,500);
    glVertex2i(700,520);
    glVertex2i(800,520);
    glVertex2i(800,500);

    glVertex2i(900,500);
    glVertex2i(900,520);
    glVertex2i(1000,520);
    glVertex2i(1000,500);

    glEnd();


}

void up_road()
{



    //Bus

    glBegin(GL_POLYGON);

    glColor3ub(102,102,255);



    glVertex2i(200,370);
    glVertex2i(190,380);
    glVertex2i(190,470);
    glVertex2i(200,480);
    glVertex2i(370,480);
    glVertex2i(380,470);
    glVertex2i(380,380);
    glVertex2i(370,370);



    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(204,255,255);
    glVertex2i(190,430);
    glVertex2i(180,430);
    glVertex2i(180,470);
    glVertex2i(190,470);



    glEnd();




    //car

    glBegin(GL_POLYGON);
    glColor3ub(255,0,127);
    glVertex2i(790,420);
    glVertex2i(600,420);
    glVertex2i(600,440);
    glVertex2i(620,440);
    glVertex2i(650,470);
    glVertex2i(770,470);
    glVertex2i(790,440);
    glVertex2i(790,420);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(160,160,160);
    glVertex2i(200,410);
    glVertex2i(200,450);
    glVertex2i(240,450);
    glVertex2i(240,410);

    glVertex2i(260,410);
    glVertex2i(260,450);
    glVertex2i(300,450);
    glVertex2i(300,410);

    glVertex2i(320,410);
    glVertex2i(320,450);
    glVertex2i(360,450);
    glVertex2i(360,410);

    //car
    glVertex2i(700,430);
    glVertex2i(680,430);
    glVertex2i(680,450);
    glVertex2i(700,450);

    glVertex2i(720,430);
    glVertex2i(740,430);
    glVertex2i(740,450);
    glVertex2i(720,450);





    glEnd();

    //bus wheel

    glColor3ub(0,0,0);
    //glColor3ub(255,255,255);
    makeCircle(12,250,370,1);
    makeCircle(12,330,370,1);

    //car wheel
    makeCircle(12,640,420,1);
    makeCircle(12,760,420,1);


    //glColor3ub(0,0,0);
    glColor3ub(255,255,255);
    makeCircle(8,250,370,0);
    makeCircle(8,330,370,0);

    //carwheel

    makeCircle(8,640,420,0);
    makeCircle(8,760,420,0);








}

void block2()
{

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2i(0,330);
    glVertex2i(0,350);
    glVertex2i(1000,350);
    glVertex2i(1000,330);
    glEnd();

    //white color

    glBegin(GL_QUADS);
    glColor3ub(255,255,255);
    glVertex2i(100,330);
    glVertex2i(100,350);
    glVertex2i(200,350);
    glVertex2i(200,330);

    glVertex2i(300,330);
    glVertex2i(300,350);
    glVertex2i(400,350);
    glVertex2i(400,330);

    glVertex2i(500,330);
    glVertex2i(500,350);
    glVertex2i(600,350);
    glVertex2i(600,330);

    glVertex2i(700,330);
    glVertex2i(700,350);
    glVertex2i(800,350);
    glVertex2i(800,330);

    glVertex2i(900,330);
    glVertex2i(900,350);
    glVertex2i(1000,350);
    glVertex2i(1000,330);

    glEnd();


}

void road_divider()
{

    glBegin(GL_QUADS);
    glColor3ub(153, 255, 153);
    glVertex2i(0,270);
    glVertex2i(0,330);
    glVertex2i(1000,330);
    glVertex2i(1000,270);
    glEnd();




}

void block3()
{

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2i(0,250);
    glVertex2i(0,270);
    glVertex2i(1000,270);
    glVertex2i(1000,250);
    glEnd();

    //white color

    glBegin(GL_QUADS);
    glColor3ub(255,255,255);
    glVertex2i(100,250);
    glVertex2i(100,270);
    glVertex2i(200,270);
    glVertex2i(200,250);

    glVertex2i(300,250);
    glVertex2i(300,270);
    glVertex2i(400,270);
    glVertex2i(400,250);

    glVertex2i(500,250);
    glVertex2i(500,270);
    glVertex2i(600,270);
    glVertex2i(600,250);

    glVertex2i(700,250);
    glVertex2i(700,270);
    glVertex2i(800,270);
    glVertex2i(800,250);

    glVertex2i(900,250);
    glVertex2i(900,270);
    glVertex2i(1000,270);
    glVertex2i(1000,250);

    glEnd();


}

void up_down_road()
{

      glBegin(GL_QUADS);
    glColor3ub(64, 64, 64);
    glVertex2i(0,350);
    glVertex2i(0,500);
    glVertex2i(1000,500);
    glVertex2i(1000,350);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(64, 64, 64);
    glVertex2i(0,100);
    glVertex2i(0,250);
    glVertex2i(1000,250);
    glVertex2i(1000,100);
    glEnd();
}

void down_road()
{





    //bus

    glBegin(GL_POLYGON);

    glColor3ub(0,102,51);


    glVertex2i(200,120);
    glVertex2i(190,130);
    glVertex2i(190,220);
    glVertex2i(200,230);
    glVertex2i(370,230);
    glVertex2i(380,220);
    glVertex2i(380,130);
    glVertex2i(370,120);

    glEnd();


glBegin(GL_QUADS);
    glColor3ub(204,255,255);
    glVertex2i(380,180);
    glVertex2i(390,180);
    glVertex2i(390,220);
    glVertex2i(380,220);



    glEnd();


//car

    glBegin(GL_POLYGON);
    glColor3ub(25,51,0);
    glVertex2i(810,170);
    glVertex2i(810,190);
    glVertex2i(790,190);
    glVertex2i(770,220);
    glVertex2i(650,220);
    glVertex2i(620,190);
    glVertex2i(620,170);
    glVertex2i(810,170);
    //glVertex2i(790,420);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(160,160,160);
    glVertex2i(200,160);
    glVertex2i(200,200);
    glVertex2i(240,200);
    glVertex2i(240,160);

    glVertex2i(260,160);
    glVertex2i(260,200);
    glVertex2i(300,200);
    glVertex2i(300,160);

    glVertex2i(320,160);
    glVertex2i(320,200);
    glVertex2i(360,200);
    glVertex2i(360,160);

    glEnd();

    //car

    glBegin(GL_QUADS);

    glVertex2i(680,180);
    glVertex2i(680,200);
    glVertex2i(700,200);
    glVertex2i(700,180);

    glVertex2i(720,180);
    glVertex2i(720,200);
    glVertex2i(740,200);
    glVertex2i(740,180);

    glEnd();


    //bus wheel

    glColor3ub(0,0,0);
    //glColor3ub(255,255,255);
    makeCircle(12,250,120,1);
    makeCircle(12,330,120,1);

    //car wheel
    makeCircle(12,660,170,1);
    makeCircle(12,760,170,1);


    //glColor3ub(0,0,0);
    glColor3ub(255,255,255);
    makeCircle(8,250,120,0);
    makeCircle(8,330,120,0);

    //carwheel

    makeCircle(8,660,170,0);
    makeCircle(8,760,170,0);

}

void block4()
{

    glBegin(GL_QUADS);
    glColor3ub(0,0,0);
    glVertex2i(0,80);
    glVertex2i(0,100);
    glVertex2i(1000,100);
    glVertex2i(1000,80);
    glEnd();

    //white color

    glBegin(GL_QUADS);
    glColor3ub(255,255,255);
    glVertex2i(100,80);
    glVertex2i(100,100);
    glVertex2i(200,100);
    glVertex2i(200,80);

    glVertex2i(300,80);
    glVertex2i(300,100);
    glVertex2i(400,100);
    glVertex2i(400,80);

    glVertex2i(500,80);
    glVertex2i(500,100);
    glVertex2i(600,100);
    glVertex2i(600,80);

    glVertex2i(700,80);
    glVertex2i(700,100);
    glVertex2i(800,100);
    glVertex2i(800,80);

    glVertex2i(900,80);
    glVertex2i(900,100);
    glVertex2i(1000,100);
    glVertex2i(1000,80);

    glEnd();


}


void ground()
{



    //whole rectangular

    glBegin(GL_QUADS);
    glColor3ub(255, 229, 204);
    glVertex2i(0,0);
    glVertex2i(0,80);
    glVertex2i(1000,80);
    glVertex2i(1000,0);
    glEnd();

//1st house
    glBegin(GL_POLYGON);
    glColor3ub(0,102,51);
    glVertex2i(200,0);
    glVertex2i(200,60);
    glVertex2i(300,60);
    glVertex2i(310,50);
    glVertex2i(310,0);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(5, 20, 5);
    glVertex2i(220,10);
    glVertex2i(220,30);
    glVertex2i(250,30);
    glVertex2i(250,10);

    glColor3ub(255, 255, 255);
    glVertex2i(220,30);
    glVertex2i(220,50);
    glVertex2i(250,50);
    glVertex2i(250,30);

    glColor3ub(5, 20, 5);
    glVertex2i(260,10);
    glVertex2i(260,30);
    glVertex2i(290,30);
    glVertex2i(290,10);

    glColor3ub(255, 255, 255);
    glVertex2i(260,30);
    glVertex2i(260,50);
    glVertex2i(290,50);
    glVertex2i(290,30);

    glEnd();

    //2nd house

    glBegin(GL_POLYGON);
    glColor3ub(255,102,255);
    glVertex2i(470,0);
    glVertex2i(470,60);
    glVertex2i(560,60);
    glVertex2i(570,50);
    glVertex2i(570,0);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(5, 20, 5);
    glVertex2i(490,20);
    glVertex2i(490,50);
    glVertex2i(520,50);
    glVertex2i(520,20);

    glColor3ub(255, 255, 255);
    glVertex2i(520,20);
    glVertex2i(520,50);
    glVertex2i(550,50);
    glVertex2i(550,20);

    glEnd();

//3rd house


    glBegin(GL_POLYGON);
    glColor3ub(102,204,0);
    glVertex2i(750,0);
    glVertex2i(750,70);
    glVertex2i(810,70);
    glVertex2i(820,60);
    glVertex2i(820,0);

    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(5, 20, 5);
    glVertex2i(770,10);
    glVertex2i(770,30);
    glVertex2i(800,30);
    glVertex2i(800,10);

    glColor3ub(255, 255, 255);
    glVertex2i(770,40);
    glVertex2i(770,60);
    glVertex2i(800,60);
    glVertex2i(800,40);

    glEnd();

//tree

    glBegin(GL_QUADS);
    glColor3ub(254, 234, 34);
    glVertex2i(130,10);
    glVertex2i(130,40);
    glVertex2i(140,40);
    glVertex2i(140,10);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(34, 230, 20);
    glVertex2i(110,40);
    glVertex2i(135,61);
    glVertex2i(160,40);
    glEnd();

    //----2nd

    glBegin(GL_QUADS);
    glColor3ub(254, 234, 34);
    glVertex2i(390,10);
    glVertex2i(390,40);
    glVertex2i(400,40);
    glVertex2i(400,10);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(34, 230, 20);
    glVertex2i(370,40);
    glVertex2i(395,61);
    glVertex2i(420,40);
    glEnd();

//---3rd

    glBegin(GL_QUADS);
    glColor3ub(254, 234, 34);
    glVertex2i(650,10);
    glVertex2i(650,40);
    glVertex2i(660,40);
    glVertex2i(660,10);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(34, 230, 20);
    glVertex2i(630,40);
    glVertex2i(655,61);
    glVertex2i(680,40);
    glEnd();

//---4th

    glBegin(GL_QUADS);
    glColor3ub(254, 234, 34);
    glVertex2i(900,10);
    glVertex2i(900,40);
    glVertex2i(910,40);
    glVertex2i(910,10);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(34, 230, 20);
    glVertex2i(880,40);
    glVertex2i(905,61);
    glVertex2i(930,40);
    glEnd();




}




void display()
{

    //clear the frame buffer
    glClear(GL_COLOR_BUFFER_BIT);
    //we will draw here

    sky();
    sun();
    block1();

    block2();
    road_divider();

    block3();
    up_down_road();


    glPushMatrix();
        glTranslatef(x1_incement,0,0);
        up_road();
        glPopMatrix();

    glPushMatrix();
        glTranslatef(x_incement,0,0);
        down_road();
        cloud();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(x_incement,0,0);
        cloud();
        glPopMatrix();

    block4();
    ground();

    tree(100, 300); //1st tree
    int x_translate = 100;
    for (int i = 1; i<=8; i++)
    {
        glPushMatrix();
        glTranslatef(x_translate, 0, 0); //x,y,z
        tree(100, 300);  //other tree
        glPopMatrix();
        x_translate = x_translate + 100;
    }

    //    glFlush();
    glutSwapBuffers();

}
void update_up(int value) {


    if(x1_incement<=0)
    {
        x1_incement=700;

    }
    else{
        x1_incement--;
    }
    glutPostRedisplay();
	glutTimerFunc(10, update_up, 0);
}
void update_down(int value) {


    if(x_incement>=1000)
    {
        x_incement=0;
    }
    else{
        x_incement++;
    }
    glutPostRedisplay();
	glutTimerFunc(10, update_down, 0); //time,functionname,value
}

void cloud1(int value) {


    if(x_incement>=700)
    {
        x_incement=0;
    }
    else{
        x_incement++;
    }
    glutPostRedisplay();
	glutTimerFunc(100000, cloud1, 0); //time,functionname,value
}

int main(int argc, char** argv)
{

    glutInit(&argc, argv);
    glutInitDisplayMode(GL_DOUBLE |  GLUT_RGB);

    glutInitWindowPosition(0, 0);
    glutInitWindowSize(1000, 700);


    glutCreateWindow("Aricha Highway");
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);

  //init();
    glutReshapeFunc(reshape);
    glutTimerFunc(0, update_up, 0);
    glutTimerFunc(0, update_down, 0);
    glutTimerFunc(0, cloud1, 0);
    glutMainLoop();


    return 0;

}
